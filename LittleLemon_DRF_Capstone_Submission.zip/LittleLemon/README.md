# Little Lemon API — Django REST Framework Capstone

This project provides a Django-rendered HTML landing page and a REST API for menu items, categories, user registration/JWT authentication, groups, carts, and orders.

See **Readme.txt** for setup instructions and the API paths your peer reviewers can test.

## Quick start (Windows PowerShell)

Create a MySQL database named `littlelemon`, then configure your local connection:

```powershell
$env:DB_NAME = "littlelemon"
$env:DB_USER = "root"
$env:DB_PASSWORD = "YOUR_MYSQL_PASSWORD"
$env:DB_HOST = "127.0.0.1"
$env:DB_PORT = "3306"
pipenv install
pipenv run python manage.py makemigrations LittleLemonAPI
pipenv run python manage.py migrate
pipenv run python manage.py test
pipenv run python manage.py runserver
```

Do not submit your real MySQL password. The reviewer should configure their own local database credentials.
