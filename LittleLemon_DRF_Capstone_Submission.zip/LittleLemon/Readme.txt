LITTLE LEMON DJANGO REST FRAMEWORK CAPSTONE
===========================================

SETUP (Windows PowerShell)
--------------------------
1. Install MySQL Server and Pipenv.
2. Create the database in MySQL:

   CREATE DATABASE littlelemon CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

3. Open PowerShell in the folder containing manage.py and set your local MySQL credentials:

   $env:DB_NAME = "littlelemon"
   $env:DB_USER = "root"
   $env:DB_PASSWORD = "YOUR_MYSQL_PASSWORD"
   $env:DB_HOST = "127.0.0.1"
   $env:DB_PORT = "3306"

4. Install packages and initialize the database:

   py -m pip install --user pipenv
   pipenv install
   pipenv run python manage.py makemigrations LittleLemonAPI
   pipenv run python manage.py migrate
   pipenv run python manage.py createsuperuser
   pipenv run python manage.py test
   pipenv run python manage.py runserver

5. Open http://127.0.0.1:8000/ for the HTML home page and
   http://127.0.0.1:8000/admin/ for Django Admin.

API PATHS FOR PEER REVIEW
-------------------------
Public menu and categories:
  GET    /api/
  GET    /api/menu-items/
  GET    /api/menu-items/?category=1
  GET    /api/menu-items/?page=2
  GET    /api/menu-items/?ordering=price
  GET    /api/categories/

Registration and authentication:
  POST   /api/auth/users/       JSON: {"username":"customer1","password":"ChooseAStrongPassword123"}
  POST   /api/token/            JSON: {"username":"customer1","password":"ChooseAStrongPassword123"}
  POST   /api/token/refresh/    JSON: {"refresh":"<refresh-token>"}
  JWT-protected requests use: Authorization: Bearer <access-token>

Manager group (admin/staff):
  GET    /api/groups/manager/users
  POST   /api/groups/manager/users
         JSON: {"username":"manager1"}
  DELETE /api/groups/manager/users
         JSON: {"username":"manager1"}

Delivery crew group (manager):
  GET    /api/groups/delivery-crew/users
  POST   /api/groups/delivery-crew/users
         JSON: {"username":"delivery1"}
  DELETE /api/groups/delivery-crew/users
         JSON: {"username":"delivery1"}

Menu item of the day (manager):
  GET    /api/menu-items-of-the-day
  PUT    /api/menu-items-of-the-day
         JSON: {"item_id":1}

Cart (authenticated customer):
  GET    /api/cart/menu-items
  POST   /api/cart/menu-items
         JSON: {"menuitem":1,"quantity":2}
  DELETE /api/cart/menu-items

Orders:
  GET    /api/orders
  POST   /api/orders
  GET    /api/orders/1
  PATCH  /api/orders/1
         Delivery crew can set {"status":"delivered"} for an assigned order.
  PATCH  /api/orders/1/assign
         Manager JSON: {"delivery_crew":"delivery1"}

INSOMNIA NOTES
--------------
For POST/PUT/PATCH requests choose JSON body and Content-Type: application/json.
Obtain a JWT using POST /api/token/ and use the access token in the Auth tab as a Bearer Token.
Create users and assign Manager or Delivery crew groups before testing role-specific routes.
Create category and menu-item records in Django Admin or through permitted API endpoints before testing cart and order routes.

DATABASE CREDENTIALS
--------------------
MySQL credentials are local to the reviewer and must be configured using environment variables above.
Create your own admin account with createsuperuser. This ZIP does not include a populated database or pre-created user accounts.
